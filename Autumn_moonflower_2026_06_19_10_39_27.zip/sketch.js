// CONFIGURAÇÕES PREMIUM - SIMULADOR ARCADE 3D
let dinheiro = 0;
let velocidadePista = 5;
let tratorX = 0;
let objetos = [];
let particulas = [];
let poeira = [];
let gameover = false;

// Variáveis de Curva e Cenário
let curvaturaEstrada = 0;
let curvaAtual = 0;
let temporizadorCurva = 0;
let montanhasOffset = 0;

function setup() {
  createCanvas(800, 500);
}

function draw() {
  if (gameover) {
    desenharTelaGameOver();
    return;
  }

  // 1. GERENCIAMENTO DE CURVAS DA PISTA (Matemática Procedural)
  temporizadorCurva--;
  if (temporizadorCurva <= 0) {
    curvaturaEstrada = random(-2, 2); // Sorteia direção da curva: Esquerda, Direita ou Reta
    temporizadorCurva = random(100, 200);
  }
  curvaAtual = lerp(curvaAtual, curvaturaEstrada, 0.03);
  montanhasOffset += curvaAtual * 0.5;

  // 2. RENDERIZAÇÃO DO CENÁRIO (Efeito Paralaxe)
  background(100, 180, 240); // Céu degradê azul-claro
  
  // Sol com brilho suave
  fill(255, 235, 120, 180);
  ellipse(width/2 - curvaAtual * 30, 220, 110);
  fill(255, 215, 0);
  ellipse(width/2 - curvaAtual * 30, 220, 80);

  // Montanhas ao Fundo (Camada Distante)
  fill(46, 125, 50);
  beginShape();
  vertex(0, 220);
  for (let x = 0; x <= width; x += 40) {
    let y = 220 - noise((x + montanhasOffset) * 0.01) * 60;
    vertex(x, y);
  }
  vertex(width, 220);
  endShape(CLOSE);

  // Gramado da Fazenda (Camada Próxima)
  fill(120, 190, 80);
  rect(0, 220, width, height - 220);

  // Desenhar a Pista de Terra com Ilusão de Perspectiva 3D Completa
  fill(130, 95, 60);
  beginShape();
  vertex(width/2 - 15 - curvaAtual * 20, 220);
  vertex(width/2 + 15 - curvaAtual * 20, 220);
  vertex(tratorX + 220, height);
  vertex(tratorX - 220, height);
  endShape(CLOSE);

  // Linhas Laterais de Sinalização da Pista
  stroke(220, 180, 120);
  strokeWeight(2);
  line(width/2 - 15 - curvaAtual * 20, 220, tratorX - 220, height);
  line(width/2 + 15 - curvaAtual * 20, 220, tratorX + 220, height);
  noStroke();

  // 3. EFICIÊNCIA DE OBJETOS EM MOVIMENTO (Feno, Vacas e Rochas)
  if (frameCount % 30 === 0) {
    let itens = ["Feno", "Feno", "Vaca", "Pedra"]; // Maior chance de feno
    objetos.push({
      x: random(-15, 15), 
      y: 220,
      z: 0.1, 
      tipo: random(itens),
      ladoCurva: curvaAtual
    });
  }

  // Loop de renderização dos objetos na pista
  for (let i = objetos.length - 1; i >= 0; i--) {
    let obj = objetos[i];
    
    // Atualização física baseada na velocidade atual
    obj.y += velocidadePista * (obj.z * 1.8);
    obj.z += 0.035; 
    
    // Cálculo avançado de distorção 3D por causa da curva da pista
    let centroPistaX = lerp(width/2 - obj.ladoCurva * 20, tratorX, map(obj.y, 220, height, 0, 1));
    let telaX = centroPistaX + obj.x * (obj.z * 12);
    let tam = obj.z * 22;

    // Desenho Gráfico Avançado por Código (Substitutos de Sprites)
    push();
    translate(telaX, obj.y);
    rectMode(CENTER);
    
    if (obj.tipo === "Feno") {
      fill(240, 190, 40); // Amarelo palha
      rect(0, 0, tam, tam * 0.8, 4);
      stroke(200, 150, 10); // Amarras do feno
      strokeWeight(tam * 0.08);
      line(-tam * 0.2, -tam * 0.4, -tam * 0.2, tam * 0.4);
      line(tam * 0.2, -tam * 0.4, tam * 0.2, tam * 0.4);
    } else if (obj.tipo === "Vaca") {
      fill(250); // Corpo da Vaca
      ellipse(0, 0, tam * 1.4, tam);
      fill(30); // Manchas pretas realistas
      ellipse(-tam * 0.2, -tam * 0.1, tam * 0.4, tam * 0.3);
      ellipse(tam * 0.3, tam * 0.1, tam * 0.5, tam * 0.4);
      // Cabeça
      fill(245, 210, 210);
      ellipse(tam * 0.7, -tam * 0.2, tam * 0.5, tam * 0.5);
    } else if (obj.tipo === "Pedra") {
      fill(100); // Base da Rocha
      beginShape();
      vertex(-tam * 0.5, tam * 0.4);
      vertex(-tam * 0.4, -tam * 0.3);
      vertex(tam * 0.2, -tam * 0.4);
      vertex(tam * 0.6, tam * 0.4);
      endShape(CLOSE);
      fill(140); // Luz/Sombra no topo da rocha
      triangle(-tam * 0.4, -tam * 0.3, tam * 0.2, -tam * 0.4, 0, 0);
    }
    pop();

    // SISTEMA DE DETECÇÃO DE IMPACTO COM O TRATOR
    if (obj.y > height - 110 && obj.y < height - 30) {
      let hitboxTrator = lerp(tratorX, mouseX, 0.25);
      if (abs(telaX - hitboxTrator) < tam + 35) {
        if (obj.tipo === "Feno") {
          dinheiro += 50;
          gerarParticulasExplosao(telaX, obj.y, color(255, 220, 50));
        } else if (obj.tipo === "Vaca") {
          dinheiro += 150;
          gerarParticulasExplosao(telaX, obj.y, color(255));
        } else if (obj.tipo === "Pedra") {
          gameover = true;
          gerarParticulasExplosao(telaX, obj.y, color(255, 50, 0));
        }
        objetos.splice(i, 1);
        continue;
      }
    }

    if (obj.y > height + 60) objetos.splice(i, 1);
  }

  // 4. MOVIMENTAÇÃO DO TRATOR E ANIMAÇÃO DE POEIRA
  let tratorAlvoX = constrain(mouseX, 180, 620);
  let diferencaX = tratorAlvoX - tratorX;
  tratorX = lerp(tratorX, tratorAlvoX, 0.25);

  // Efeito de poeira nas rodas se movendo
  if (frameCount % 3 === 0) {
    poeira.push({ x: tratorX - 55, y: height - 20, tam: random(10, 25), alfa: 150 });
    poeira.push({ x: tratorX + 55, y: height - 20, tam: random(10, 25), alfa: 150 });
  }
  desenharEAtualizarPoeira();

  // 5. RENDERIZAR TRATOR EM PERSPECTIVA PREMIUM
  push();
  // Trepidação mecânica sutil do motor do trator
  let trepidação = sin(frameCount * 0.8) * 1.2;
  translate(tratorX, height - 55 + trepidação);
  
  // Inclinação nas curvas de alta velocidade
  let inclinacao = constrain(diferencaX * 0.08, -8, 8);
  rotate(inclinacao);
  rectMode(CENTER);

  // Sombras Projetadas sob o veículo
  fill(0, 0, 0, 80);
  ellipse(0, 35, 140, 20);

  // Reboque Traseiro de Carga
  fill(120, 60, 20);
  rect(0, 25, 115, 35, 4);
  fill(60, 30, 10);
  rect(0, 25, 105, 25);

  // Cabine do Piloto (Teto e Vidros)
  fill(20, 20, 20);
  rect(0, -32, 60, 6, 2); // Teto Preto
  fill(160, 220, 255, 180);
  quad(-25, -10, 25, -10, 20, -28, -20, -28); // Vidro Frontal espelhado

  // Capô Frontal Verde (Estilo John Deere Moderno)
  fill(40, 140, 50);
  rect(0, 0, 76, 45, 6);
  fill(20, 80, 25);
  rect(0, -5, 50, 35, 4);

  // Grade de Ventilação e Faróis de LED Esportivos
  fill(15);
  rect(0, -16, 54, 10, 2);
  fill(255, 255, 220); // Farol Esquerdo
  rect(-20, -16, 10, 5, 1);
  fill(255, 255, 220); // Farol Direito
  rect(20, -16, 10, 5, 1);

  // Rodas Enormes de Borracha com Calotas Pratas
  fill(25); // Pneu Esquerdo
  rect(-47, 10, 18, 50, 6);
  fill(180);
  rect(-47, 10, 6, 20, 2);

  fill(25); // Pneu Direito
  rect(47, 10, 18, 50, 6);
  fill(180);
  rect(47, 10, 6, 20, 2);
  
  // Escapamento Soltando Fumaça Ativa
  fill(50);
  ellipse(-25, -5, 6, 6);
  if (frameCount % 5 === 0) {
    particulas.push({ x: tratorX - 25, y: height - 65, vx: random(-1, 0), vy: random(-2, -4), c: color(80), a: 180, t: 8 });
  }
  pop();

  // 6. ATUALIZAR INTERFACES E PARTÍCULAS
  atualizarParticulasFumaça();
  desenharHUDPremium();
}

// FUNÇÕES DE EFEITOS ESPECIAIS VISUAIS
function desenharEAtualizarPoeira() {
  for (let i = poeira.length - 1; i >= 0; i--) {
    let p = poeira[i];
    p.y -= 1.5;
    p.alfa -= 6;
    p.tam += 0.5;
    fill(160, 130, 90, p.alfa);
    noStroke();
    ellipse(p.x, p.y, p.tam);
    if (p.alfa <= 0) poeira.splice(i, 1);
  }
}

function gerarParticulasExplosao(x, y, cor) {
  for (let i = 0; i < 15; i++) {
    particulas.push({
      x: x, y: y,
      vx: random(-4, 4), vy: random(-5, -1),
      c: cor, a: 255, t: random(5, 10)
    });
  }
}

function atualizarParticulasFumaça() {
  for (let i = particulas.length - 1; i >= 0; i--) {
    let p = particulas[i];
    p.x += p.vx;
    p.y += p.vy;
    p.a -= 8;
    fill(p.c, p.c, p.c, p.a);
    ellipse(p.x, p.y, p.t);
    if (p.a <= 0) particulas.splice(i, 1);
  }
}

function desenharHUDPremium() {
  // Painel Superior de Vidro Fumê
  fill(0, 0, 0, 160);
  stroke(255, 255, 255, 50);
  rect(20, 20, 260, 60, 8);
  noStroke();

  // Texto Placar Digital
  fill(255);
  textFont("Courier New");
  textSize(22);
  textStyle(BOLD);
  text("RENDA: R$ " + dinheiro, 40, 42);
  
  textSize(11);
  fill(200);
  textStyle(NORMAL);
  text("Velocidade: " + (velocidadePista * 12) + " km/h", 40, 65);
}

function desenharTelaGameOver() {
  background(15, 15, 25);
  fill(255, 60, 60);
  textSize(45);
  textAlign(CENTER, CENTER);
  text("ACIDENTE DE TRATOR!", width/2, height/2 - 30);
  
  fill(255);
  textSize(20);
  text("Total faturado na colheita: R$ " + dinheiro, width/2, height/2 + 25);
  
  fill(100, 200, 255);
  textSize(15);
  text("Clique na tela para consertar o motor e reiniciar", width/2, height/2 + 75);
}

function mousePressed() {
  if (gameover) {
    dinheiro = 0;
    objetos = [];
    particulas = [];
    poeira = [];
    gameover = false;
  }
}
